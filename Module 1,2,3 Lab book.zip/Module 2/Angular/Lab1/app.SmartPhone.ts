export class SmartPhone
{
  mobileType:string;
  public constructor(mobileType:string)
  {
    this.mobileType = mobileType;
  }
}