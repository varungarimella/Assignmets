import { BrowserModule } from '@angular/platform-browser';

import { NgModule } from '@angular/core';


import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';


import { mobilecomponent } from './app.mobilecomponent';
import { FormsModule } from '@angular/forms';

@NgModule({

  declarations: [

    AppComponent
,mobilecomponent  
   ],

  imports: [

    BrowserModule,

    AppRoutingModule,
    FormsModule
  ],

  providers: [],

  bootstrap: [mobilecomponent,AppComponent]

})

export class AppModule { }
