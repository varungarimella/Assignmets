import { Component } from '@angular/core';
import { Mobile } from './app.mobile';
import { mobileList } from './app.mobileList';

@Component({
  selector:'first-element',
  templateUrl:'./app.mobile.html',
  styles:['']
})

export class mobilecomponent
{
  mob:Mobile[] =mobileList;
}